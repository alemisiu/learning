package com.example.demo.repository;



import com.example.demo.model.Matka;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MatkaRepository extends JpaRepository <Matka, Integer> {

}

