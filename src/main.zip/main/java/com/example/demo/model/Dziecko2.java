package com.example.demo.model;

import javax.persistence.*;


@Entity
public class Dziecko2 {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idDziecko;
    private String imie;
    private String nazwisko;

    @ManyToOne
    @JoinColumn(name = "matka")
    private Matka2 matka;

    public Matka2 getMatka() {
        return matka;
    }

    public void setMatka(Matka2 matka) {
        this.matka = matka;
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public Dziecko2(String imie, String nazwisko) {
        this.imie = imie;
        this.nazwisko = nazwisko;
    }

    public Dziecko2(String imie, String nazwisko, Matka2 matka) {
        this.imie = imie;
        this.nazwisko = nazwisko;
      this.matka=matka;
    }

    public Dziecko2() {
    }

    @Override
    public String toString() {
        return "Dziecko{" +
                "imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                '}';
    }


}