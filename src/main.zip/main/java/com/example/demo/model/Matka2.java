package com.example.demo.model;

import javax.persistence.*;
import java.util.List;

@Entity
public class Matka2 {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idMatka;
    private String imie;
    private String nazwisko;
    @OneToMany( cascade = CascadeType.ALL, mappedBy="matka",
            fetch = FetchType.EAGER
    )

    private List<Dziecko2> dzieci;

    public Matka2() {
    }

    public Integer getIdMatka() {
        return idMatka;
    }

    public void setIdMatka(Integer idMatka) {
        this.idMatka = idMatka;
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public List<Dziecko2> getDzieci() {
        return dzieci;
    }

    public void setDzieci(List<Dziecko2> dzieci) {
        this.dzieci = dzieci;
    }

    public Matka2(String imie, String nazwisko, List<Dziecko2> dzieci) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.dzieci = dzieci;
    }

    public Matka2(String imie, String nazwisko) {
        this.imie = imie;
        this.nazwisko = nazwisko;
    }


}