package com.example.demo.model;
import org.hibernate.annotations.LazyToOne;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Entity
public class Osoba {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idOsoba;
    private String imie;
    private String nazwisko;



    @OneToOne (cascade = CascadeType.ALL)
    @JoinColumn(name="telefonID")
    private Telefon telefon;

/*
    @ManyToOne(cascade = CascadeType.ALL)
    private Firma firma;

    @ManyToMany
    private List<ProducenciTelefonow> producenciTelefonow;
*/




    public Osoba(String imie, String nazwisko, String numerTelefonu) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.telefon = new Telefon(numerTelefonu);

  //      this.producenciTelefonow=new ArrayList<>();
    }

    public Osoba(String imie, String nazwisko, Telefon obiektTelefon) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.telefon = obiektTelefon;

 //       this.producenciTelefonow=new ArrayList<>();
    }

    public Osoba(String imie, String nazwisko) {
        this.imie = imie;
        this.nazwisko = nazwisko;
    }
/*
public void dodajProducenciTelefonow(ProducenciTelefonow producenciTelefonow) {

    this.producenciTelefonow.add(producenciTelefonow);


}
*/

    public Osoba() {
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public Telefon getNumerTelefonu() {
        return telefon;
    }

    public void setNumerTelefonu(Telefon numerTelefonu) {
        this.telefon = numerTelefonu;
    }

    @Override
    public String toString() {
        return "Osoba{" +
                "id=" + idOsoba +
                ", imie='" + imie + '\'' +
                ", nazwisko='" + nazwisko + '\'' +
                ", numerTelefonu=" + telefon +
                '}';
    }

    public Telefon getTelefon() {
        return telefon;
    }

    public void setTelefon(Telefon telefon) {
        this.telefon = telefon;
    }
/*
    public Firma getFirma() {
        return firma;
    }

    public void setFirma(Firma firma) {
        this.firma = firma;
    }

   public List<ProducenciTelefonow> getProducenciTelefonow() {
        return producenciTelefonow;
    }

    public void setProducenciTelefonow(List<ProducenciTelefonow> producenciTelefonow) {
        this.producenciTelefonow = producenciTelefonow;
    }


   */
}


