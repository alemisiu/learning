package com.example.demo;

  import com.example.demo.controller.SaveFromWeb;
  import com.example.demo.model.*;
  // import com.example.demo.repository.FirmaRepository;
  import com.example.demo.repository.*;
  import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

  import java.util.Arrays;
  import java.util.List;

@Component

public class AfterRun {

  //  public static Firma  google;

 //   FirmaRepository firmaRepository;
    OsobaRepository osobaRepository;
    TelefonRepository telefonRepository;
    MatkaRepository matkaRepository;
    MatkaRepository2 matkaRepository2;
    DzieckoRepository2 dzieckoRepository2;
@Autowired
public void AfterRun(
        //FirmaRepository firmaRepository,
        OsobaRepository osobaRepository, TelefonRepository telefonRepository, MatkaRepository matkaRepository, MatkaRepository2 matkaRepository2,DzieckoRepository2 dzieckoRepository2 ){

//   this.firmaRepository= firmaRepository;
   this.osobaRepository=osobaRepository;
   this.telefonRepository=telefonRepository;
    this.matkaRepository=matkaRepository;
    this.matkaRepository2=matkaRepository2;
    this.dzieckoRepository2=dzieckoRepository2;

}

@EventListener(ApplicationReadyEvent.class)
    public void anyWihoutName(){

 //   EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MMPersistence");
 //   EntityManager entityManager = entityManagerFactory.createEntityManager();

    Telefon telefon = new Telefon("1234");
    Osoba osoba = new Osoba("Jan", "Kowalski");
    osoba.setTelefon(telefon);
    telefon.setOsoba(osoba);
    osobaRepository.save(osoba);
  //  telefonRepository.save(telefon); // MOŻNA POMINĄĆ


    System.out.println("Nazwisko osoby o numerze: "+telefon.getNumerTelefonu()+" to: "+telefon.getOsoba().getNazwisko());
    System.out.println("-------dane z bazy:------------");
    System.out.println("Telefon:"+telefonRepository.findAll());
    System.out.println("-------------------");
    System.out.println("Osoba:"+osobaRepository.findAll());
    System.out.println(osoba);


    //Telefon telefon2 = new Telefon("5678");
 Osoba osoba2 = new Osoba("Anna", "Nowak", "5678");
  //  osoba2.setTelefon(telefon2);
 //   telefon2.setOsoba(osoba2);
    osobaRepository.save(osoba2);




    System.out.println("-------dane z bazy:------------");
    System.out.println("Telefon:"+telefonRepository.findAll());
    System.out.println("-------------------");
    System.out.println("Osoba:"+osobaRepository.findAll());


    System.out.println("Wyświetlamy dane z poziomu telefonu o jego właścicielu ");
    for (Telefon telefonik : telefonRepository.findAll()) {
        System.out.println(telefonik.getOsoba());
    }



    System.out.println(telefonRepository.findByNumerTelefonu("1234").getOsoba().getNazwisko());
    System.out.println(telefonRepository.findByNumerTelefonu("5678").getOsoba().getNazwisko());

    Matka matka1=new Matka("Anna", "Kowalska");

    List<Dziecko> dzieckoList = Arrays.asList(
            new Dziecko("Krzyś", "Kowalski"),
            new Dziecko("Karolinka", "Kowalski"),
            new Dziecko("Zosia", "Kowalska"),
            new Dziecko("Marcinek", "Kowalski"));

    matka1.setDzieci(dzieckoList);

     matkaRepository.save(matka1);


    List<Matka> MamaZBazy=matkaRepository.findAll();

    for (Matka matka : MamaZBazy) {
        System.out.println(matka.getDzieci());
    }
//-----------------------------------


    Matka2 matka2= new Matka2("Anna", "Nowak");
    Matka2 matka3= new Matka2("Jola", "Bąk");
/*
    List<Dziecko2> dzieckoList2 = Arrays.asList(
            new Dziecko2("Krzyś", "Nowak", matka2),
            new Dziecko2("Karolinka", "Nowak" , matka2),
            new Dziecko2("Zosia", "Nowak" , matka2),
            new Dziecko2("Marcinek", "Nowak" , matka2));

    List<Dziecko2> dzieckoList3 = Arrays.asList(
            new Dziecko2("Krzyś", "Bąk"),
            new Dziecko2("Karolinka", "Bąk"),
            new Dziecko2("Zosia", "Bąk"),
            new Dziecko2("Marcinek", "Bąk"));

    matka2.setDzieci(dzieckoList2);
    matka3.setDzieci(dzieckoList3);

    matkaRepository2.save(matka2);
    matkaRepository2.save(matka3);


    List<Dziecko2> dzieckoZBazy=dzieckoRepository2.findAll();

    for (Dziecko2 dziecko: dzieckoZBazy) {
        System.out.println(dziecko);
    }
    System.out.println("Imię Dziecka: "+dzieckoZBazy.get(1).getImie()+", ");
    System.out.println("Nazwisko Dziecka: "+dzieckoZBazy.get(1).getNazwisko());
  System.out.println("Nazwisko Mamy: "+dzieckoZBazy.get(1).getMatka().getNazwisko());

 //  System.out.println(matkaRepository.findAll());


   // System.out.println(dziecciZBazy);


 /*

        Firma tesla = new Firma("Tesla");
        Firma ibm = new Firma("IBM");
        Firma nasa = new Firma("NASA");

        firmaRepository.save(tesla);
        firmaRepository.save(ibm);
        firmaRepository.save(nasa);
        */


    }



}
