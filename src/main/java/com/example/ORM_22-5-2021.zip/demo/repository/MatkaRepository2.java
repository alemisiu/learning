package com.example.demo.repository;



import com.example.demo.model.Matka2;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MatkaRepository2 extends JpaRepository <Matka2, Integer> {

}

