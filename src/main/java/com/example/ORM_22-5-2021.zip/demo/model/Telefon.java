package com.example.demo.model;
import javax.persistence.*;

@Entity
public class Telefon {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idTelefon;
    private String numerTelefonu;

   @OneToOne(mappedBy = "telefon" , cascade ={CascadeType.ALL}) //podajemy nazwę pola z klasy będącej właścicielem relacji
    Osoba osoba;


    public Osoba getOsoba() {
        return osoba;
    }

    public void setOsoba(Osoba osoba) {
        this.osoba = osoba;
    }

    public Telefon(String numerTelefonu, Osoba osoba) {
        this.numerTelefonu = numerTelefonu;
        this.osoba=osoba;
    }


    public Telefon(String numerTelefonu ) {
        this.numerTelefonu = numerTelefonu;

    }
    public Telefon() {
    }

    public String getNumerTelefonu() {
        return numerTelefonu;
    }

    public void setNumerTelefonu(String numerTelefonu) {
        this.numerTelefonu = numerTelefonu;
    }

    @Override
    public String toString() {
        return "Telefon{" +
                "idTelefon=" + idTelefon +
                ", numerTelefonu='" + numerTelefonu + '\'' +
          //    ", osoba=" + osoba +
                '}';
    }
}
