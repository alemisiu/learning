package com.example.demo.model;

import javax.persistence.*;
import java.util.List;

@Entity
public class Matka {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idMatka;
    private String imie;
    private String nazwisko;
    @OneToMany( cascade = CascadeType.ALL
           ,    fetch = FetchType.EAGER //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    )
    @JoinColumn(name = "dzieciId")

    private List<Dziecko> dzieci;

    public Matka() {
    }

    public Integer getIdMatka() {
        return idMatka;
    }

    public void setIdMatka(Integer idMatka) {
        this.idMatka = idMatka;
    }

    public String getImie() {
        return imie;
    }

    public void setImie(String imie) {
        this.imie = imie;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public void setNazwisko(String nazwisko) {
        this.nazwisko = nazwisko;
    }

    public List<Dziecko> getDzieci() {
        return dzieci;
    }

    public void setDzieci(List<Dziecko> dzieci) {
        this.dzieci = dzieci;
    }

    public Matka(String imie, String nazwisko, List<Dziecko> dzieci) {
        this.imie = imie;
        this.nazwisko = nazwisko;
        this.dzieci = dzieci;
    }

    public Matka(String imie, String nazwisko) {
        this.imie = imie;
        this.nazwisko = nazwisko;
    }
}