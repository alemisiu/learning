package com.example.demo.model;

import javax.persistence.*;
import java.util.*;

// @Entity
public class Firma {
/*
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer idFirma;
    private String nazwaFirmy;

    @OneToMany(mappedBy = "firma", cascade = CascadeType.ALL)
    private List<Osoba> osoby;

    public Firma(String nazwaFirmy) {
       this.nazwaFirmy = nazwaFirmy;
       this.osoby=new ArrayList<>();
    }

    public void setNazwaFirmy(String nazwaFirmy) {
        this.nazwaFirmy = nazwaFirmy;
    }

    public Firma() {
    }

    public void wypelniamyKolekcjeOsobami(Osoba osoba) {

        osoby.add(osoba);

    }

 */
}
