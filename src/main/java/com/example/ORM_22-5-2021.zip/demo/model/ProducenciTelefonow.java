package com.example.demo.model;


import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

// @Entity
public class ProducenciTelefonow {
    /*
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idProducencieTelefonow;
    private String nazwaProducentaTelefonow;

    public ProducenciTelefonow(String nazwaProducentaTelefonow ) {
        this.nazwaProducentaTelefonow = nazwaProducentaTelefonow;
        osoby = new ArrayList<>();
    }
    @ManyToMany(mappedBy = "producenciTelefonow",   cascade = CascadeType.ALL)
    private List<Osoba>osoby;



    public void wypelniamyKolekcjeOsobami(Osoba osoba){
        osoby.add(osoba);
    }

    public ProducenciTelefonow() {
    }
*/
}
