package com.example.demo.controller;
import com.example.demo.model.Firma;
import com.example.demo.model.Osoba;
import com.example.demo.AfterRun;
import com.example.demo.model.Telefon;
// import com.example.demo.repository.FirmaRepository;
import com.example.demo.repository.OsobaRepository;
import com.example.demo.repository.TelefonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
public class SaveFromWeb {

    private OsobaRepository osobaRepository;
    private TelefonRepository telefonRepository;
  //  private FirmaRepository firmaRepository;
 //   Firma google = new Firma("Google");


    public SaveFromWeb (OsobaRepository osobaRepository, TelefonRepository telefonRepository
            //, FirmaRepository firmaRepository
                        ) {
        this.osobaRepository = osobaRepository;
        this.telefonRepository = telefonRepository;
 //       this.firmaRepository=firmaRepository;
    }

    @RequestMapping("/firmaSave")
    public String dodajemyDane(
            @RequestParam("firma") String nazwaFirmy){

   //  firmaRepository.save(new Firma(nazwaFirmy));
       return "Dodałem firmę do bazy";
    }


    @RequestMapping("/save")
    public String dodajemyDane(
            @RequestParam("imie") String imie,
            @RequestParam("nazwisko") String nazwisko,
            @RequestParam("telefon") String numerTelefonu)  throws Exception
    {



    //    Telefon telefon = new Telefon(numerTelefonu);
        Osoba osoba = new Osoba(imie, nazwisko, numerTelefonu);

 // telefon.setOsoba(osoba);
 // osoba.setTelefon(telefon);


     //   telefonRepository.save(telefon);
    osobaRepository.save(osoba);



     //   google.wypelniamyKolekcjeOsobami(osoba);
     //  firmaRepository.save(google);


        System.out.println("-------------------");
        System.out.println(osoba);

        System.out.println("-------------------");


    //    System.out.println(osoba.getNumerTelefonu());




        return "osoba: "+osoba;
    }
}
